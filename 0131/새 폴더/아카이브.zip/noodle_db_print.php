<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>라면 DB 출력 예제</title>
</head>
<body>
<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');

//1. 변수 선언 (서버주소, 아이디, 비밀번호, 데이터베이스명)
$mysql_host = 'localhost';
$mysql_user = 'root';
$mysql_password='';
$mysql_db = 'goods';

//2. 데이터베이스 연결
$conn = mysqli_connect($mysql_host, $mysql_user, $mysql_password, $mysql_db);

//3. 데이터베이스 연결 확인
if(mysqli_connect_errno()){
  printf ("데이터베이스 연결 실패: %s\n", mysqli_connect_error());
  exit();
}


//4. 데이터 조회하기
$query = "SELECT * FROM noodle";
$result = mysqli_query($conn, $query); //조회결과를 변수에 담기

//5. 출력하기
print "<table border=1>";
print "<tr><th>번호</th><th>이름</th><th>제조사</th><th>종류</th><th>가격</th><th>유통기한</th></tr>";
while( $row = mysqli_fetch_row($result) ) {
  print "<tr><td>" . $row[0] . "</td>" . 
          "<td>" . $row[1] . "</td>" . 
          "<td>" . $row[2] . "</td>" . 
          "<td>" . $row[3] . "</td>". 
          "<td>" . $row[4] . "</td>". 
          "<td>" . $row[5] . "</td></tr>";
}
print "</table>";
mysqli_free_result($result);
mysqli_close($conn);
?>

<a href="db_noodle_data_insert.html" title="데이터 입력">라면정보 입력하러가기</a>
</body>
</html>

