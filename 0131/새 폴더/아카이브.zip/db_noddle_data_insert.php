<?php
error_reporting(E_ALL & E_STRICT);
ini_set('display_errors', '1');
ini_set('log_errors', '0');
ini_set('error_log', './');

//변수선언
$name = $_POST['name'];
$company = $_POST['company'];
$kind = $_POST['kind'];
$price = $_POST['price'];
$e_date = $_POST['e_date'];


//데이터베이스 계정 설정
$mysql_host = 'localhost';
$mysql_user = '';
$mysql_password='';
$mysql_db = '';

//데이터베이스 계정 연결하기
$conn = mysqli_connect($mysql_host, $mysql_user, $mysql_password, $mysql_db);

if(!$conn){
  printf ("데이터베이스 연결 실패: %s\n", mysqli_connect_error());
  exit();
}
//데이터베이스 noddle테이블 데이터 모두 조회하여 변수에 대입
$query = "INSERT INTO noodle (name, company, kind, price, e_date)  VALUES ('$name', '$company', '$kind', $price, '$e_date')";

$result = mysqli_query($conn, $query); //조회결과를 변수에 담기
echo '<p>입력완료<p> <a href="./noodle_db_print.php" title="돌아가기">돌아가기</a> <a href="./db_noodle_data_insert.html" title="추가입력">추가입력하기</a>';

?>